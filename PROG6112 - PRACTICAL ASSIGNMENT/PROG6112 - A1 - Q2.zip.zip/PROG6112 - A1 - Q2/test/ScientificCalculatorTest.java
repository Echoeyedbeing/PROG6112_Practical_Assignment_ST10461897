/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Nishaal
 */
public class ScientificCalculatorTest
{
    private ScientificCalculator scientificCalculator;
    
    @Test
    public void testSqrt() {
        assertEquals(3.0, scientificCalculator.sqrt(9.0));
        assertEquals(0.0, scientificCalculator.sqrt(0.0));
        assertThrows(ArithmeticException.class, () -> {
            scientificCalculator.sqrt(-1.0);
        });
    }

    @Test
    public void testPower() {
        assertEquals(8.0, scientificCalculator.power(2.0, 3.0));
        assertEquals(1.0, scientificCalculator.power(5.0, 0.0));
        assertEquals(0.25, scientificCalculator.power(2.0, -2.0));
    }
}
