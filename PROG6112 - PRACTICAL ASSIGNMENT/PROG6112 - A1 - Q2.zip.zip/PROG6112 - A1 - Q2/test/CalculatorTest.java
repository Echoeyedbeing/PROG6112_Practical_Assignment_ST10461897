/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Nishaal
 */
public class CalculatorTest
{
    private Calculator calculator;
    
    public CalculatorTest()
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass()
    {
    }
    
    @Before
    public void setUp()
    {
        calculator = new Calculator();
    }
    
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testAdd() {
        assertEquals(5.0, calculator.add(2.0, 3.0));
        assertEquals(0.0, calculator.add(0.0, 0.0));
        assertEquals(-3.0, calculator.add(-5.0, 2.0));
    }


    @Test
    public void testSubtract() {
        assertEquals(1.0, calculator.subtract(3.0, 2.0));
        assertEquals(0.0, calculator.subtract(5.0, 5.0));
        assertEquals(-7.0, calculator.subtract(-5.0, 2.0));
    }

    @Test
    public void testMultiply() {
        assertEquals(6.0, calculator.multiply(2.0, 3.0));
        assertEquals(0.0, calculator.multiply(0.0, 5.0));
        assertEquals(-10.0, calculator.multiply(-5.0, 2.0));
    }

    @Test
    public void testDivide() {
        assertEquals(2.0, calculator.divide(6.0, 3.0));
        assertEquals(0.0, calculator.divide(0.0, 5.0));
        assertThrows(ArithmeticException.class, () -> {
            calculator.divide(1.0, 0.0);
        });
    }

}