/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//Code attribution:
//This code was adapted from Stack Overflow
//Author: Jonny Stewart
//https://stackoverflow.com/questions/13479731/joptionpane-showoptiondialog

//Code attribution:
//This code was adapted from GeeksForGeeks
//Author: chinmaya121221
//https://www.geeksforgeeks.org/java-joptionpane/
/**
 *
 * @author Nishaal
 */
public class Calculator
{
private double[] recentResults;
private static final int MAX_RESULTS = 10;
private int resultCount;

// Constructor
    public Calculator() {
        this.recentResults = new double[MAX_RESULTS];
        this.resultCount = 0;
    }
    
//Addition
    public double add(double a, double b)
    {
     double result = a + b;
     storeResult(result);
     return result;
    }
    
//Subtraction
    public double subtract(double a, double b)
    {
     double result = a - b;
     storeResult(result);
     return result;
    }
    
//multiplication
    public double multiply(double a, double b)
    {
     double result = a*b;
     storeResult(result);
     return result;
    }
    
//division
   public double divide(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Division by zero is not allowed.");
        }
        double result = a / b;
        storeResult(result);
        return result;
    }
    
     // Store result in recent results array
    protected void storeResult(double result) {
        if (resultCount >= MAX_RESULTS) {
            shiftResults();
        }
        recentResults[resultCount++] = result;
    }
    
     // Shift results to make room for new results
    private void shiftResults() {
        System.arraycopy(recentResults, 1, recentResults, 0, MAX_RESULTS - 1);
    }
    
     // Get recent results
    public double[] getRecentResults() {
        double[] results = new double[resultCount];
        System.arraycopy(recentResults, 0, results, 0, resultCount);
        return results;
    }
 
}
