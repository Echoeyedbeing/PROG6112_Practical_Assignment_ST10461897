
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//Code attribution:
//This code was adapted from Stack Overflow
//Author: Jonny Stewart
//https://stackoverflow.com/questions/13479731/joptionpane-showoptiondialog

//Code attribution:
//This code was adapted from GeeksForGeeks
//Author: chinmaya121221
//https://www.geeksforgeeks.org/java-joptionpane/
/**
 *
 * @author Nishaal
 */
public class Application {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ScientificCalculator calc = new ScientificCalculator();
        double mostRecentResult = 0;

        while (true) {
            System.out.println("Select operation: ");
            System.out.println("===============================");
            System.out.println("1: Add");
            System.out.println("2: Subtract");
            System.out.println("3: Multiply");
            System.out.println("4: Divide");
            System.out.println("5: Square Root");
            System.out.println("6: Power");
            System.out.println("7: View Recent Results");
            System.out.println("8: Quit");
            System.out.println("===============================");

            int choice = scanner.nextInt();
            if (choice == 8) {
                System.out.println("Exiting...");
                break;
            }

            switch (choice) {
                case 1:
                case 2:
                case 3:
                case 4:
                    System.out.println("===============================");
                    System.out.print("Enter first number: ");
                    double num1 = scanner.nextDouble();
                    System.out.print("Enter second number: ");
                    double num2 = scanner.nextDouble();
                    switch (choice) {
                        case 1:
                            mostRecentResult = calc.add(num1, num2);
                            break;
                        case 2:
                            mostRecentResult = calc.subtract(num1, num2);
                            break;
                        case 3:
                            mostRecentResult = calc.multiply(num1, num2);
                            break;
                        case 4:
                            mostRecentResult = calc.divide(num1, num2);
                            break;
                    }
                    System.out.println("===============================");
                    System.out.println("Result: " + mostRecentResult);
                    break;
                case 5:
                    System.out.println("===============================");
                    System.out.print("Enter number: ");
                    double num = scanner.nextDouble();
                    mostRecentResult = calc.sqrt(num);
                    System.out.println("===============================");
                    System.out.println("Result: " + mostRecentResult);
                    break;
                case 6:
                    System.out.println("===============================");
                    System.out.print("Enter base: ");
                    double base = scanner.nextDouble();
                    System.out.print("Enter exponent: ");
                    double exponent = scanner.nextDouble();
                    mostRecentResult = calc.power(base, exponent);
                    System.out.println("===============================");
                    System.out.println("Result: " + mostRecentResult);
                    break;
                case 7:
                    double[] recentResults = calc.getRecentResults();
                    System.out.println("===============================");
                    System.out.println("Recent Results:");
                    for (double res : recentResults) {
                        System.out.println(res);
                    }
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }

            
            if (choice != 7) { 
                System.out.println("===============================");
                System.out.print("Do you want to view recent results? (Y/N): ");
    
                String response = scanner.next();
                if (response.equalsIgnoreCase("Y")) {
                    double[] recentResults = calc.getRecentResults();
                    System.out.println("===============================");
                    System.out.println("Recent Results:");
                    
                    for (double res : recentResults) {
                        System.out.println(res);
                    }
                }
            }
        }
        scanner.close();
    }
}