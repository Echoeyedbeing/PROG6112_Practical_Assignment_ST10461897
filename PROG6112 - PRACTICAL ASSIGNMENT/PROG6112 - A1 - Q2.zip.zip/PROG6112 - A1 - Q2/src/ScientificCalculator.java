/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//Code attribution:
//This code was adapted from Stack Overflow
//Author: Jonny Stewart
//https://stackoverflow.com/questions/13479731/joptionpane-showoptiondialog

//Code attribution:
//This code was adapted from GeeksForGeeks
//Author: chinmaya121221
//https://www.geeksforgeeks.org/java-joptionpane/
/**
 *
 * @author Nishaal
 */
public class ScientificCalculator extends Calculator {
    // Constructor
    public ScientificCalculator() {
        super();
    }

    // Scientific methods
    public double sqrt(double a) {
        if (a < 0) {
            throw new ArithmeticException("Cannot calculate the square root of a negative number.");
        }
        double result = Math.sqrt(a);
        storeResult(result);
        return result;
    }

    public double power(double base, double exponent) {
        double result = Math.pow(base, exponent);
        storeResult(result);
        return result;
    }

}
