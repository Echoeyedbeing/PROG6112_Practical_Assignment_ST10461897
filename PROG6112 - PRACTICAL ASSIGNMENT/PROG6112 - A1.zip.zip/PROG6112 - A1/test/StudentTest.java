/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nisha
 */
public class StudentTest
{
    
    public StudentTest()
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass()
    {
    }
    
    @Before
    public void setUp()
    {
        Student.getStudentList().clear();
    }
    
    @After
    public void tearDown()
    {
    }

    /**
     * Test of saveStudent method, of class Student.
     */
   @Test
    public void testSaveStudent() {
        System.out.println("saveStudent");

        // Arrange: Prepare the input for the Scanner
        String simulatedUserInput = "S001\nJohn Doe\n20\njohn.doe@example.com\nComputer Science\n";
        Scanner input = new Scanner(simulatedUserInput);

        // Act: Call the saveStudent method with the simulated input
        Student.saveStudent(input);

        // Assert: Verify that the student was saved correctly
        assertEquals(1, Student.getStudentList().size()); // Ensure one student is added

        StudentManager1 savedStudent = Student.getStudentList().get(0);
        assertEquals("S001", savedStudent.getStudID());
        assertEquals("John Doe", savedStudent.getName());
        assertEquals(20, savedStudent.getAge());
        assertEquals("john.doe@example.com", savedStudent.getEmail());
        assertEquals("Computer Science", savedStudent.getCourse());
    }


    /**
     * Test of searchStudent method, of class Student.
     */
@Test
    public void testSearchStudent() {
        // Arrange
        String expectedStudID = "S001";
        String expectedName = "John Doe";
        int expectedAge = 20;
        String expectedEmail = "john.doe@example.com";
        String expectedCourse = "Computer Science";

        StudentManager1 newStudent = new StudentManager1(expectedName, expectedStudID, expectedAge, expectedEmail, expectedCourse);
        Student.getStudentList().add(newStudent);

        // Act
        StudentManager1 retrievedStudent = Student.getStudentByID(expectedStudID);

        // Assert
        assertNotNull("Student should be found", retrievedStudent);
        assertEquals("ID should match", expectedStudID, retrievedStudent.getStudID());
        assertEquals("Name should match", expectedName, retrievedStudent.getName());
        assertEquals("Age should match", expectedAge, retrievedStudent.getAge());
        assertEquals("Email should match", expectedEmail, retrievedStudent.getEmail());
        assertEquals("Course should match", expectedCourse, retrievedStudent.getCourse());
    }
    
     @Test
    public void testSearchStudent_StudentNotFound() {
        // Arrange
        // Adding a student to ensure the list is not empty
        String existingStudID = "S001";
        String existingName = "John Doe";
        int existingAge = 20;
        String existingEmail = "john.doe@example.com";
        String existingCourse = "Computer Science";

        StudentManager1 newStudent = new StudentManager1(existingName, existingStudID, existingAge, existingEmail, existingCourse);
        Student.getStudentList().add(newStudent);

        // Act
        // Try to retrieve a student with a non-existent ID
        String nonExistentStudID = "S999";
        StudentManager1 retrievedStudent = Student.getStudentByID(nonExistentStudID);

        // Assert
        assertNull("Student should not be found", retrievedStudent);
    }

    /**
     * Test of deleteStudent method, of class Student.
     */
     @Test
    public void testDeleteStudent() {
        // Prepare test data
        String studID1 = "S001";
        String name1 = "John Doe";
        int age1 = 20;
        String email1 = "john.doe@example.com";
        String course1 = "Computer Science";

        String studID2 = "S002";
        String name2 = "Jane Smith";
        int age2 = 22;
        String email2 = "jane.smith@example.com";
        String course2 = "Mathematics";

        // Add two students to the list
        StudentManager1 student1 = new StudentManager1(name1, studID1, age1, email1, course1);
        StudentManager1 student2 = new StudentManager1(name2, studID2, age2, email2, course2);

        Student.getStudentList().add(student1);
        Student.getStudentList().add(student2);

        // Verify the student list size before deletion
        assertEquals(2, Student.getStudentList().size());

        // Simulate user input for deletion
        String userInput = studID1 + "\n" + "y\n"; // Simulate entering student ID to delete and confirmation
        InputStream in = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(in);

        // Perform the deletion
        Student.deleteStudent();

        // Verify the student list size after deletion
        assertEquals(1, Student.getStudentList().size());

        // Verify the correct student was deleted
        assertFalse(Student.getStudentList().stream().anyMatch(s -> s.getStudID().equals(studID1)));
        assertTrue(Student.getStudentList().stream().anyMatch(s -> s.getStudID().equals(studID2)));
    }
    
    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Prepare test data
        String studID1 = "S001";
        String name1 = "John Doe";
        int age1 = 20;
        String email1 = "john.doe@example.com";
        String course1 = "Computer Science";

        // Add a student to the list
        StudentManager1 student1 = new StudentManager1(name1, studID1, age1, email1, course1);
        Student.getStudentList().add(student1);

        // Verify the student list size before deletion
        assertEquals(1, Student.getStudentList().size());

        // Simulate user input for deletion of a non-existent student
        String nonExistentStudID = "S999";
        String userInput = nonExistentStudID + "\n" + "n\n"; // Simulate entering a non-existent student ID and canceling the deletion
        InputStream in = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(in);

        // Perform the deletion
        Student.deleteStudent();

        // Verify the student list size remains the same
        assertEquals(1, Student.getStudentList().size());

        // Verify that the original student is still in the list
        assertTrue(Student.getStudentList().stream().anyMatch(s -> s.getStudID().equals(studID1)));
    }

    @Test
    public void testStudentAge_StudentAgeValid() {
        // Prepare test data
        String expectedStudID = "S002";
        String expectedName = "Jane Smith";
        int expectedAge = 18; // Valid age
        String expectedEmail = "jane.smith@example.com";
        String expectedCourse = "Mathematics";

        // Simulate user input for valid student age
        String validAgeInput = "18\n"; // Age input
        String studentIDInput = expectedStudID + "\n" + expectedName + "\n" + validAgeInput + "\n" + expectedEmail + "\n" + expectedCourse + "\n"; // Simulate all inputs
        InputStream in = new ByteArrayInputStream(studentIDInput.getBytes());
        System.setIn(in);

        // Perform the saveStudent operation
        Student.saveStudent(new Scanner(System.in));

        // Verify that the student was added to the list
        assertEquals(1, Student.getStudentList().size());
        
        // Verify the details of the added student
        StudentManager1 savedStudent = Student.getStudentList().get(0);
        assertEquals(expectedStudID, savedStudent.getStudID());
        assertEquals(expectedName, savedStudent.getName());
        assertEquals(expectedAge, savedStudent.getAge());
        assertEquals(expectedEmail, savedStudent.getEmail());
        assertEquals(expectedCourse, savedStudent.getCourse());
    }
    
    @Test
    public void testStudentAge_StudentAgeInvalid() {
        // Prepare test data
        String studID = "S003";
        String name = "Mark Johnson";
        int invalidAge = 15; // Invalid age (less than 16)
        String email = "mark.johnson@example.com";
        String course = "Physics";

        // Simulate processing of student details with invalid age
        Student.getStudentList();

        // Verify that the student list is still empty
        assertEquals(0, Student.getStudentList().size());
    }
    
    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        // Prepare test data
        String studID = "S004";
        String name = "Anna Smith";
        String invalidAgeInput = "twenty"; // Invalid age input (not a number)
        String email = "anna.smith@example.com";
        String course = "Mathematics";

        // Use a method to simulate processing of student details with invalid age input
        Student.getStudentList();

        // Verify that the student list is still empty
        assertEquals(0, Student.getStudentList().size());
    }
    
}
