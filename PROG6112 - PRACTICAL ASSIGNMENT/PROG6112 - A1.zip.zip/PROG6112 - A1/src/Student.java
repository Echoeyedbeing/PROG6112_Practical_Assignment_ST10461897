/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//Code attribution:
//This code was adapted from Stack Overflow
//Author: Jonny Stewart
//https://stackoverflow.com/questions/13479731/joptionpane-showoptiondialog

//Code attribution:
//This code was adapted from GeeksForGeeks
//Author: chinmaya121221
//https://www.geeksforgeeks.org/java-joptionpane/

/**
 * @author Nishaal
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
    private static ArrayList<StudentManager1> studentList = new ArrayList<>();

    public static void saveStudent(Scanner input) {
        System.out.println("--------------------------------------");
        System.out.println("ENTER STUDENT DETAILS");
        System.out.println("--------------------------------------");

        System.out.print("Enter the student ID: ");
        String studID = input.nextLine();

        System.out.print("Enter student name: ");
        String name = input.nextLine();

        int age = 0;
        boolean validAge = false;

        System.out.print("Enter the student age: ");
        while (!validAge) {
            String ageInput = input.nextLine();
            if (ageInput.matches("\\d+")) {
                age = Integer.parseInt(ageInput);
                if (age >= 16) {
                    validAge = true;
                } else {
                    System.out.println("--------------------------------------");
                    System.out.print("You have entered an incorrect student age!!!\nPlease re-enter the student age>>");
                    System.out.println("--------------------------------------");
                }
            }
        }

        System.out.print("Enter student email: ");
        String email = input.nextLine();

        System.out.print("Enter student course: ");
        String course = input.nextLine();

        StudentManager1 newStudent = new StudentManager1(name, studID, age, email, course);
        studentList.add(newStudent);

        System.out.println("--------------------------------------");
        System.out.println("STUDENT DETAILS SUCCESSFULLY CAPTURED");
        System.out.println("--------------------------------------");
    }

    public static ArrayList<StudentManager1> getStudentList() {
        return studentList;
    }
 public static void searchStudent() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter student ID to search for: ");
        String studID = input.nextLine();

        for (StudentManager1 student : studentList) {
            if (student.getStudID().equals(studID)) {
                System.out.println("--------------------------------------");
                System.out.println("STUDENT DETAILS");
                System.out.println("ID: " + student.getStudID());
                System.out.println("Name: " + student.getName());
                System.out.println("Age: " + student.getAge());
                System.out.println("Email: " + student.getEmail());
                System.out.println("Course: " + student.getCourse());
                System.out.println("--------------------------------------");
                input.close();
                return;
            }
        }
        System.out.println("Student with ID " + studID + " not found.");
        input.close();
    }
 
 
 public static void deleteStudent() {
        Scanner input = new Scanner(System.in);
        System.out.println("--------------------------------------");
        System.out.print("Enter student ID to delete: ");
        System.out.println("--------------------------------------");
        String studID = input.nextLine();

        StudentManager1 studentToRemove = null;

        // Find the student to remove
        for (StudentManager1 student : studentList) {
            if (student.getStudID().equals(studID)) {
                studentToRemove = student;
                break;
            }
        }

        if (studentToRemove != null) {
            System.out.println("--------------------------------------");
            System.out.print("Are you sure you want to delete this student? (y/n): ");
            System.out.println("--------------------------------------");
            String confirmation = input.nextLine();

            if (confirmation.equalsIgnoreCase("y")) {
                studentList.remove(studentToRemove); 
                System.out.println("--------------------------------------");
                System.out.println("Student with ID " + studID + " has been deleted.");
                System.out.println("--------------------------------------");
            } else {
                System.out.println("--------------------------------------");
                System.out.println("Deletion cancelled.");
                System.out.println("--------------------------------------");
            }
        } else {
            System.out.println("--------------------------------------");
            System.out.println("Student with ID " + studID + " not found.");
            System.out.println("--------------------------------------");
        }

        input.close();
    }
 
  public static void studentReport() {
        if (studentList.isEmpty()) {
            System.out.println("No students available.");
            return;
        }

        int index = 1; // Start indexing from 1
        System.out.println("Student " + index);
        System.out.println("--------------------------------------");
        for (StudentManager1 student : studentList) {
            System.out.println("ID: " + student.getStudID());
            System.out.println("Name: " + student.getName());
            System.out.println("Age: " + student.getAge());
            System.out.println("Email: " + student.getEmail());
            System.out.println("Course: " + student.getCourse());
            System.out.println("--------------------------------------");
            index++;
        }
    }
  
  public static StudentManager1 getStudentByID(String studID) {
    for (StudentManager1 student : studentList) {
        if (student.getStudID().equals(studID)) {
            return student;
        }
    }
    return null; // Return null if the student is not found
}

  
  
}


