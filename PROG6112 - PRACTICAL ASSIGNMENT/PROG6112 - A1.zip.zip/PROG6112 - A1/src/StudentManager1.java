/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//Code attribution:
//This code was adapted from Stack Overflow
//Author: Jonny Stewart
//https://stackoverflow.com/questions/13479731/joptionpane-showoptiondialog

//Code attribution:
//This code was adapted from GeeksForGeeks
//Author: chinmaya121221
//https://www.geeksforgeeks.org/java-joptionpane/
/**
 * @author Nishaal
 */

public class StudentManager1 
{
    private String name;
    private String studID;
    private int age;
    private String email;
    private String course;

    public StudentManager1(String name, String studID, int age, String email, String course) {
        this.name = name;
        this.studID = studID;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public String getName()
    {
        return name;
    }

    public String getStudID()
    {
        return studID;
    }

    public int getAge()
    {
        return age;
    }

    public String getEmail()
    {
        return email;
    }

    public String getCourse()
    {
        return course;
    }

   
}
