/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//Code attribution:
//This code was adapted from Stack Overflow
//Author: Jonny Stewart
//https://stackoverflow.com/questions/13479731/joptionpane-showoptiondialog

//Code attribution:
//This code was adapted from GeeksForGeeks
//Author: chinmaya121221
//https://www.geeksforgeeks.org/java-joptionpane/
/**
 *
 * @author Nishaal
 */
import java.util.Scanner;

public class Application {

    public static void main(String[] args) {
        // Display the title
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("===============================");

        Scanner input = new Scanner(System.in);

        while (true) {
            // Prompt the user to enter 1 to go to the main menu or any other key to exit
            System.out.print("Enter 1 to go to the Main Menu or any other key to exit: ");
            String initialChoice = input.nextLine();

            if (!initialChoice.equals("1")) {
                System.out.println("Exiting the application...");
                break;  // Exit the application
            }

            String choice;
            do {
                // Display main menu options
                System.out.println("--------------------------------------");
                System.out.println("\nMAIN MENU");
                System.out.println("--------------------------------------");
                System.out.println("1. Capture new student");
                System.out.println("2. Search for student");
                System.out.println("3. Delete student");
                System.out.println("4. Show student report");
                System.out.println("5. Exit the application");
                 System.out.println("--------------------------------------");

                System.out.print("Enter your choice: ");
                choice = input.nextLine();

                switch (choice) {
                    case "1":
                        Student.saveStudent(input);// Capture new student
                        break;
                    case "2":
                        Student.searchStudent();  // Search for student
                        break;
                    case "3":
                        Student.deleteStudent();  // Delete student
                        break;
                    case "4":
                        Student.studentReport();  // Show student report
                        break;
                    case "5":
                        System.out.println("Exiting the application...");
                        break;  // Exit the loop and application
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                }
            } while (!choice.equals("5"));  // Continue displaying the menu until the user selects option 5
        }

        // Close the Scanner object here, only when the application is about to exit
        input.close();
    }
}
